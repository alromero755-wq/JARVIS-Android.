package com.example.jarvis

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val commandEngine = CommandEngine()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(10, 16, 29)
        val cyan = Color.rgb(0, 220, 255)
        val white = Color.WHITE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 32f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val subtitle = TextView(this).apply {
            text = "ASISTENTE LOCAL · VERSIÓN 1.0"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        val status = TextView(this).apply {
            text = "● Sistema iniciado"
            textSize = 15f
            setTextColor(Color.rgb(100, 255, 160))
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(20))
        }

        val input = EditText(this).apply {
            hint = "Escribe: hola, hora, fecha..."
            textSize = 16f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(27, 36, 54))
        }

        val sendButton = Button(this).apply {
            text = "EJECUTAR COMANDO"
            setTextColor(Color.BLACK)
            setBackgroundColor(cyan)
        }

        val responseTitle = TextView(this).apply {
            text = "RESPUESTA DEL SISTEMA"
            textSize = 12f
            setTextColor(cyan)
            setPadding(0, dp(28), 0, dp(8))
        }

        val response = TextView(this).apply {
            text = "J.A.R.V.I.S. está listo. Escribe «ayuda» para comenzar."
            textSize = 18f
            setTextColor(white)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(Color.rgb(20, 29, 45))
        }

        val hint = TextView(this).apply {
            text = "Esta versión de prueba responde sin internet. El micrófono, la palabra de activación y las funciones en segundo plano todavía no están incorporados."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(20), 0, 0)
        }

        sendButton.setOnClickListener {
            response.text = commandEngine.respond(input.text.toString())
        }

        input.setOnEditorActionListener { _, _, _ ->
            response.text = commandEngine.respond(input.text.toString())
            true
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(status, matchWrap())
        root.addView(input, matchWrap())
        val buttonParams = matchWrap().apply { topMargin = dp(12) }
        root.addView(sendButton, buttonParams)
        root.addView(responseTitle, matchWrap())
        root.addView(response, matchWrap())
        root.addView(hint, matchWrap())

        val scroll = ScrollView(this).apply {
            addView(root)
            isFillViewport = true
        }
        setContentView(scroll)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
